CREATE DATABASE IF NOT EXISTS civicpulse;
USE civicpulse;
CREATE TABLE IF NOT EXISTS departments (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS citizens (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, email VARCHAR(150) UNIQUE NOT NULL, phone VARCHAR(20));
CREATE TABLE IF NOT EXISTS complaints (id INT AUTO_INCREMENT PRIMARY KEY, citizen_id INT NOT NULL, department_id INT NULL, title VARCHAR(150) NOT NULL, category ENUM('Garbage','Streetlight','Road','Water','Other') NOT NULL, description TEXT NOT NULL, location VARCHAR(255) NOT NULL, status ENUM('Registered','Assigned','In Progress','Resolved','Closed') DEFAULT 'Registered', priority ENUM('Low','Medium','High') DEFAULT 'Medium', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, resolved_at DATETIME NULL, FOREIGN KEY(citizen_id) REFERENCES citizens(id), FOREIGN KEY(department_id) REFERENCES departments(id));
CREATE TABLE IF NOT EXISTS complaint_history (id INT AUTO_INCREMENT PRIMARY KEY, complaint_id INT NOT NULL, old_status VARCHAR(30), new_status VARCHAR(30) NOT NULL, note VARCHAR(255), changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(complaint_id) REFERENCES complaints(id));
CREATE TABLE IF NOT EXISTS escalations (id INT AUTO_INCREMENT PRIMARY KEY, complaint_id INT NOT NULL, reason TEXT NOT NULL, escalated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(complaint_id) REFERENCES complaints(id));
DROP TRIGGER IF EXISTS complaint_insert_history;
DROP TRIGGER IF EXISTS complaint_update_history;
DELIMITER $$
CREATE TRIGGER complaint_insert_history AFTER INSERT ON complaints FOR EACH ROW BEGIN INSERT INTO complaint_history(complaint_id,new_status,note) VALUES(NEW.id,NEW.status,'Complaint registered'); END$$
CREATE TRIGGER complaint_update_history AFTER UPDATE ON complaints FOR EACH ROW BEGIN IF NOT (OLD.status <=> NEW.status) THEN INSERT INTO complaint_history(complaint_id,old_status,new_status,note) VALUES(NEW.id,OLD.status,NEW.status,'Status updated'); END IF; END$$
DROP PROCEDURE IF EXISTS assign_complaint$$
CREATE PROCEDURE assign_complaint(IN p_id INT, IN p_department INT) BEGIN DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END; START TRANSACTION; UPDATE complaints SET department_id=p_department,status='Assigned' WHERE id=p_id AND status='Registered'; IF ROW_COUNT()=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Complaint not found or not registered'; END IF; COMMIT; END$$
DROP PROCEDURE IF EXISTS resolve_complaint$$
CREATE PROCEDURE resolve_complaint(IN p_id INT) BEGIN DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END; START TRANSACTION; UPDATE complaints SET status='Resolved',resolved_at=NOW() WHERE id=p_id AND status IN ('Assigned','In Progress'); IF ROW_COUNT()=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Complaint cannot be resolved'; END IF; COMMIT; END$$
DELIMITER ;
CREATE OR REPLACE VIEW department_performance AS SELECT d.id,d.name,COUNT(c.id) total_complaints,COALESCE(SUM(c.status IN ('Resolved','Closed')),0) resolved,COALESCE(SUM(c.status NOT IN ('Resolved','Closed')),0) pending,ROUND(AVG(CASE WHEN c.resolved_at IS NOT NULL THEN TIMESTAMPDIFF(HOUR,c.created_at,c.resolved_at) END),1) avg_resolution_hours FROM departments d LEFT JOIN complaints c ON c.department_id=d.id GROUP BY d.id,d.name;
INSERT IGNORE INTO departments(name) VALUES ('Sanitation'),('Electricity'),('Road Maintenance'),('Water Supply'),('General');
