USE civicpulse;
-- Join: complaint details
SELECT c.id,c.title,z.name citizen,d.name department,c.status FROM complaints c JOIN citizens z ON z.id=c.citizen_id LEFT JOIN departments d ON d.id=c.department_id;
-- View: department metrics
SELECT * FROM department_performance;
-- Aggregation: outstanding complaints by category
SELECT category,COUNT(*) pending FROM complaints WHERE status NOT IN ('Resolved','Closed') GROUP BY category ORDER BY pending DESC;
-- Escalation audit
SELECT c.id,c.title,e.reason,e.escalated_at FROM escalations e JOIN complaints c ON c.id=e.complaint_id ORDER BY e.escalated_at DESC;
-- Example stored procedure usage after registering complaint and finding department IDs:
-- CALL assign_complaint(1,1);
-- CALL resolve_complaint(1);
