# CivicPulse
MySQL Workbench + Flask API + HTML/CSS/JavaScript frontend (VS Code).

## Setup
1. Install MySQL Server and MySQL Workbench. Open `database/schema.sql` in Workbench and execute the entire script (lightning bolt). This creates `civicpulse` and sample departments. `database/analytics.sql` contains reporting queries.
2. Open this folder in VS Code. In a terminal:
   ```bash
   cd backend
   python -m venv .venv
   ```
   Activate: Windows `.venv\Scripts\activate`; macOS/Linux `source .venv/bin/activate`.
   ```bash
   pip install -r requirements.txt
   ```
3. Copy `backend/.env.example` to `backend/.env`, and enter your actual MySQL credentials. Never commit `.env`.
4. In the backend terminal run `python app.py` (API at http://127.0.0.1:5000).
5. Open `frontend/index.html` with VS Code Live Server (or run `python -m http.server 5500` inside `frontend` and visit http://localhost:5500).

## Demo flow
Register a complaint, assign it to a department, mark In Progress, resolve it, view history, and inspect analytics. Escalations are recorded separately. Trigger automatically logs registration and status transitions. Stored procedures use transactions for assignment and resolution.

## Notes
This is an educational local demo, not production-ready: administrative actions are intentionally unauthenticated. Add login/roles, validation, pagination, CSRF protections, and restricted CORS before deployment. The database account needs permission to create triggers and routines. Do not use real citizens' personal data for demonstrations.
