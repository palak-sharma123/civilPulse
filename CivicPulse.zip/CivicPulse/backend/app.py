import os
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import mysql.connector
from mysql.connector import Error
load_dotenv()
app=Flask(__name__)
CORS(app)
def connect():
    return mysql.connector.connect(host=os.getenv('DB_HOST','localhost'),port=int(os.getenv('DB_PORT','3306')),user=os.getenv('DB_USER','root'),password=os.getenv('DB_PASSWORD',''),database=os.getenv('DB_NAME','civicpulse'))
def query(sql,params=(),one=False):
    db=connect()
    try:
        cur=db.cursor(dictionary=True);cur.execute(sql,params);return cur.fetchone() if one else cur.fetchall()
    finally: db.close()
def write(sql,params=(),procedure=False):
    db=connect()
    try:
        cur=db.cursor();cur.callproc(sql,params) if procedure else cur.execute(sql,params);db.commit();return cur.lastrowid
    except: db.rollback();raise
    finally: db.close()
@app.errorhandler(Error)
def db_error(e): return jsonify(error=str(e)),400
@app.get('/api/departments')
def departments(): return jsonify(query('SELECT * FROM departments ORDER BY name'))
@app.get('/api/complaints')
def complaints(): return jsonify(query('SELECT c.*,z.name citizen_name,d.name department_name FROM complaints c JOIN citizens z ON z.id=c.citizen_id LEFT JOIN departments d ON d.id=c.department_id ORDER BY c.created_at DESC'))
@app.post('/api/complaints')
def create():
    a=request.get_json() or {}; required=['name','email','title','category','description','location']
    if any(not str(a.get(k,'')).strip() for k in required): return jsonify(error='Missing required fields'),400
    if a['category'] not in ['Garbage','Streetlight','Road','Water','Other']: return jsonify(error='Invalid category'),400
    db=connect()
    try:
        cur=db.cursor();db.start_transaction()
        cur.execute('INSERT INTO citizens(name,email,phone) VALUES(%s,%s,%s) ON DUPLICATE KEY UPDATE name=VALUES(name),phone=VALUES(phone)',(a['name'],a['email'],a.get('phone','')))
        cur.execute('SELECT id FROM citizens WHERE email=%s',(a['email'],)); citizen=cur.fetchone()[0]
        cur.execute('INSERT INTO complaints(citizen_id,title,category,description,location) VALUES(%s,%s,%s,%s,%s)',(citizen,a['title'],a['category'],a['description'],a['location']))
        cid=cur.lastrowid;db.commit();return jsonify(id=cid,message='Complaint registered'),201
    except: db.rollback();raise
    finally: db.close()
@app.get('/api/complaints/<int:cid>/history')
def history(cid): return jsonify({'history':query('SELECT * FROM complaint_history WHERE complaint_id=%s ORDER BY changed_at,id',(cid,)),'escalations':query('SELECT * FROM escalations WHERE complaint_id=%s ORDER BY escalated_at,id',(cid,))})
@app.post('/api/complaints/<int:cid>/assign')
def assign(cid):
    a=request.get_json() or {}
    if not a.get('department_id'): return jsonify(error='department_id required'),400
    write('assign_complaint',(cid,int(a['department_id'])),True);return jsonify(message='Assigned')
@app.post('/api/complaints/<int:cid>/resolve')
def resolve(cid): write('resolve_complaint',(cid,),True);return jsonify(message='Resolved')
@app.post('/api/complaints/<int:cid>/progress')
def progress(cid):
    write("UPDATE complaints SET status='In Progress' WHERE id=%s AND status='Assigned'",(cid,));return jsonify(message='Updated if assigned')
@app.post('/api/complaints/<int:cid>/escalate')
def escalate(cid):
    reason=(request.get_json() or {}).get('reason','').strip()
    if not reason:return jsonify(error='Reason required'),400
    write('INSERT INTO escalations(complaint_id,reason) VALUES(%s,%s)',(cid,reason));return jsonify(message='Escalated')
@app.get('/api/analytics')
def analytics():return jsonify({'departments':query('SELECT * FROM department_performance'),'statuses':query('SELECT status,COUNT(*) count FROM complaints GROUP BY status'),'pending':query("SELECT id,title,category,created_at FROM complaints WHERE status NOT IN ('Resolved','Closed') ORDER BY created_at")})
if __name__=='__main__':app.run(debug=True,port=5000)
